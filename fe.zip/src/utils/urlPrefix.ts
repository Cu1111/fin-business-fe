const prefix = '/ibf/api';

export default prefix;
