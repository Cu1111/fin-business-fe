export const ENABLE_FLAG = [
  { label: '启用', value: 'Y' },
  { label: '未启用', value: 'N' },
];
