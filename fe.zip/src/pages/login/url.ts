import prefix from '@/utils/urlPrefix';

const Url = {
  login: `${prefix}/hr/login`,
};

export default Url;
