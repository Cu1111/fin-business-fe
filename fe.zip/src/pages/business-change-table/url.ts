import prefix from '@/utils/urlPrefix';

const Url = {
  getAccBigTableList: `${prefix}/midwayacc/accbigtable/getAccBigTableList`,
  getAccCombo: `${prefix}/base/getAccCombo`,
};

export default Url;
