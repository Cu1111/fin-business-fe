import prefix from '@/utils/urlPrefix';

const Url = {
  getMidWayList: `${prefix}/midway/getMidWayList`,
};

export default Url;
